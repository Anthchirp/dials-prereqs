
:mod:`matplotlib.backends.backend_gtk3agg`
==========================================

**TODO** We'll add this later, importing the gtk3 backends requires an active
X-session, which is not compatible with cron jobs.

.. .. automodule:: matplotlib.backends.backend_gtk3agg
..    :members:
..    :undoc-members:
..    :show-inheritance:
