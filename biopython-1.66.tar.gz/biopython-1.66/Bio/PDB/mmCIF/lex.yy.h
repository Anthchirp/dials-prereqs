void mmcif_set_file(FILE *fp);

int mmcif_get_token(void);

char *mmcif_get_string(void);
