framer is a tool to generate boilerplate code for C extension types.

The boilerplate is generated from a specification object written in
Python.  The specification uses the class statement to describe the
extension module and any extension types it contains.  From the
specification, framer can generate all the boilerplate C code,
including function definitions, argument handling code, and type
objects.
