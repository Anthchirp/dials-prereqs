# -*- coding: utf-8 -*-

master_doc = 'index'
html_theme = 'classic'
exclude_patterns = ['_build']
