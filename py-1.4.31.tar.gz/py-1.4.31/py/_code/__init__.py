""" python inspection/code generation API """
