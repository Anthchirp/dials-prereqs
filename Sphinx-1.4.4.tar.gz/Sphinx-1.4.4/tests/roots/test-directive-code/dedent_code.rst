Dedent
======

Code blocks
-----------

.. code-block:: ruby
   :linenos:
   :dedent: 0

       def ruby?
           false
       end

.. code-block:: ruby
   :linenos:
   :dedent: 1

       def ruby?
           false
       end

.. code-block:: ruby
   :linenos:
   :dedent: 2

       def ruby?
           false
       end

.. code-block:: ruby
   :linenos:
   :dedent: 3

       def ruby?
           false
       end

.. code-block:: ruby
   :linenos:
   :dedent: 4

       def ruby?
           false
       end

.. code-block:: ruby
   :linenos:
   :dedent: 1000

       def ruby?
           false
       end
