#ifndef __DEMO_COMMON_H__
#define __DEMO_COMMON_H__

G_BEGIN_DECLS

gchar *demo_find_file (const gchar  *base,
		       GError      **err);

G_END_DECLS

#endif /* __DEMO_COMMON_H__ */
