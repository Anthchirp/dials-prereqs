
Release announcements
===========================================

.. toctree::
   :maxdepth: 2


   sprint2016
   release-2.9.0
   release-2.8.7
   release-2.8.6
   release-2.8.5
   release-2.8.4
   release-2.8.3
   release-2.8.2
   release-2.7.2
   release-2.7.1
   release-2.7.0
   release-2.6.3
   release-2.6.2
   release-2.6.1
   release-2.6.0
   release-2.5.2
   release-2.5.1
   release-2.5.0
   release-2.4.2
   release-2.4.1
   release-2.4.0
   release-2.3.5
   release-2.3.4
   release-2.3.3
   release-2.3.2
   release-2.3.1
   release-2.3.0
   release-2.2.4
   release-2.2.2
   release-2.2.1
   release-2.2.0
   release-2.1.3
   release-2.1.2
   release-2.1.1
   release-2.1.0
   release-2.0.3
   release-2.0.2
   release-2.0.1
   release-2.0.0

