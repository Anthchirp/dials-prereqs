"""Automated tests. Run with nosetests."""
