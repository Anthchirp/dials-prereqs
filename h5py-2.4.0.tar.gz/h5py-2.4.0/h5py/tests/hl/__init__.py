from . import  (test_dataset_getitem, 
                test_dims_dimensionproxy,
                test_file, )
                
MODULES = ( test_dataset_getitem, 
            test_dims_dimensionproxy,
            test_file, )