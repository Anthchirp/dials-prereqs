==================================================
Getting started basics
==================================================

.. toctree::
   :maxdepth: 2

   getting-started
   usage
   goodpractices
   projects
   faq

