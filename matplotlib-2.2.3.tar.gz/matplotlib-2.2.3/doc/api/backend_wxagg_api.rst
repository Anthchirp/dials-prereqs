
:mod:`matplotlib.backends.backend_wxagg`
========================================

.. automodule:: matplotlib.backends.backend_wxagg
   :members:
   :undoc-members:
   :show-inheritance:
