# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
#

"""Code for working with NMR data

This directory currently contains contributions from

Bob Bussell <rgb2003@med.cornell.edu> -- NOEtools and xpktools
"""
