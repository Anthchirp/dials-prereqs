.. highlight:: rest

:mod:`sphinx.ext.githubpages` -- Publish HTML docs in GitHub Pages
==================================================================

.. module:: sphinx.ext.githubpages
   :synopsis: Publish HTML docs in GitHub Pages

.. versionadded:: 1.4

This extension creates ``.nojekyll`` file on generated HTML directory to publish
the document on GitHub Pages.
