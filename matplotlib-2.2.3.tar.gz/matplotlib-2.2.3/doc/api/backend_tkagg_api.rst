
:mod:`matplotlib.backends.backend_tkagg`
========================================

.. automodule:: matplotlib.backends.backend_tkagg
   :members:
   :undoc-members:
   :show-inheritance:
