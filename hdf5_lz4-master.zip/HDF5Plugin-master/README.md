# HDF5Plugin
A repository for HDF5 Plugin filters, using HDF5 > 1.8.11

This repository is no longer maintained and considered as deprecated. If you want 
to contribute to the HDF5 external filters code base or download the 
source code to build the plugins please proceed to the new [official 
repository for the external filter plugins](https://github.com/nexusformat/HDF5-External-Filter-Plugins).
