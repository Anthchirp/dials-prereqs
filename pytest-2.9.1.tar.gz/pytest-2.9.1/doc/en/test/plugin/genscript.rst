
(deprecated) generate standalone test script to be distributed along with an application.
============================================================================


.. contents::
  :local:



command line options
--------------------


``--genscript=path``
    create standalone ``pytest`` script at given target path.

Start improving this plugin in 30 seconds
=========================================


1. Download `pytest_genscript.py`_ plugin source code
2. put it somewhere as ``pytest_genscript.py`` into your import path
3. a subsequent ``pytest`` run will use your local version

Checkout customize_, other plugins_ or `get in contact`_.

.. include:: links.txt
